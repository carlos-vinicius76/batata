<?php
    $valor = 100;

    if($valor>50){
        echo "Valor maior que 50";
    }else{
        echo "Valor menor que 50";
    }

?>