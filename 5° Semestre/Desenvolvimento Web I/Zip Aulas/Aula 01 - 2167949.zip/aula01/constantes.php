<?php
    define("VALOR",10);
    define("FRUTA","Manga");

    echo "Fruta = ".FRUTA."<br>";
    echo "Valor = ".VALOR;
?>