<?php
    /*
    Programa: sintaxe.php
    Autor: Felipe Perez
    Data: 30/03/2020
    */
?>
<!DOCTYOE html>
<html lang="pt-br">
    <head>
        <title>Primeira Página PHP</title>
    </head>
    <body>
        <h1>
        <?php
            echo "Primeira página no PHP!".date("d-m-Y H:i:s");
        ?>
        </h1>
    </body>
</html>