<?php

    $i = 10; //Inteiro
    $nome = "Felipe"; //String
    $falso =  FALSE; //Booleano
    $valor = 100.50; //Ponto Fluante

    echo $nome." - ".$i."<br>".$falso." - ".$valor;

?>