<?php
    include_once('array.php');

    include_once('array.php');
?>