<?php
    echo date("d/m/Y h:i:s")."<br>";
    echo date("d/m/Y")."<br>";
    echo date("Y/m/d")."<br>";


    $data = new DateTime('2020-04-05');
    print_r($data);
?>